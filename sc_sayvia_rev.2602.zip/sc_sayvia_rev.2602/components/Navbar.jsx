import { useState, useEffect } from "react";
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Box,
  IconButton,
  Drawer,
  Stack,
} from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import { useSayviaTheme } from "../theme/SayviaThemeProvider";
import { hover } from "@testing-library/user-event/dist/hover";
import sayviaTheme, { size, weight } from "../theme/sayviaTheme";

const menuItems = ["Harga", "Desain", "FAQ"];

const Navbar = () => {
  const [open, setOpen] = useState(false);
  const { colors } = useSayviaTheme();

const [scrolled, setScrolled] = useState(false);

useEffect(() => {
  const handleScroll = () => {
    setScrolled(window.scrollY > 1000);
  };

  window.addEventListener("scroll", handleScroll);
  return () => window.removeEventListener("scroll", handleScroll);
}, []);
  
  return (
    <>
      <AppBar
        position="sticky"
        elevation={0}
        sx={{
          backgroundColor: colors.backgroundPastel,
          backdropFilter: scrolled ? "blur(8px)" : "none",
          boxShadow: scrolled
            ? "0 4px 20px rgba(0,0,0,0.08)"
            : "none",
          transition: "all 0.3s ease",
        }}
      >
        <Toolbar
          sx={{
            justifyContent: "space-between",
            width: "90%",
            mx: "auto",
          }}
        >
          {/* LOGO */}
          <Box sx={{ display: "flex", alignItems: "center" }}>
            <IconButton 
              href="/"
              disableRipple
              sx={{
                p: 0,
                backgroundColor: "transparent",
                "&hover": {
                  backgroundColor: "transparent",
                },
              }} >
              <img
                src="/assets/icons/logo_say_hor.webp"
                alt="Sayvia"
                style={{ height: 36 }}
              />
            </IconButton>
          </Box>

          {/* MENU DESKTOP */}
          <Box
            sx={{
              display: { xs: "none", md: "flex" },
              gap: "clamp(3px, 1.2vw, 21px)",
              alignItems: "center",
            }}
          >
            {menuItems.map((item) => (
              <Button
                key={item}
                component="button"
                disableRipple
                disableElevation
                sx={{
                  position: "relative",
                  overflow: "hidden",
                  color: colors.primary,
                  fontSize: size.h3,
                  fontWeight: weight.medium,
                  textTransform: "none",

                  "&, &:hover, &:focus, &:active": {
                    textDecoration: "none !important",
                  },

                  border: "none",
                  boxShadow: "none",
                  background: "transparent",

                  transition: "color 0.3s ease, font-weight 0.3s ease",

                  "&::before": {
                    content:'""',
                    position: "absolute",
                    inset: 0,
                    backgroundColor: colors.primary,
                    transform: "scaleY(0)",
                    transformOrigin: "bottom",
                    transition: "transform 0.3s ease",
                    zIndex: -1,
                  },

                  "&:hover::before": {
                    transform: "scaleY(1)",
                  },

                  "&:hover": {
                    color: colors.white,
                    fontSize: size.h3,
                    fontWeight: weight.semiBold,
                  }
                }}
              >
                {item}
              </Button>
            ))}
          </Box>

          {/* CTA DESKTOP */}
          <Box sx={{ display: { xs: "none", md: "flex" } }}>
            <Button
              sx={{
                px: 2,
                borderRadius: "7px",
                backgroundColor: colors.primary,
                color: colors.white,
                fontSize: size.h3,
                fontWeight: weight.semiBold,
                textTransform: "none",
                transition: "transform 0.3s ease, background-color 0.3s ease",
                willChange: "transform",

                "&:hover": {
                  backgroundColor: colors.buttonHover,
                  transform: "translateY(-2px)",
                },
              }}
            >
              Pesan Sekarang!
            </Button>
          </Box>

          {/* MOBILE ICON */}
          <IconButton
            sx={{ display: { xs: "flex", md: "none" }, color: colors.primary }}
            onClick={() => setOpen(true)}
          >
            <MenuIcon />
          </IconButton>
        </Toolbar>
      </AppBar>

      {/* MOBILE DRAWER */}
      <Drawer anchor="right" open={open} onClose={() => setOpen(false)}>
        <Box sx={{ width: 260, p: 3 }}>
          <Typography
            sx={{
              fontWeight: 800,
              mb: 3,
              color: colors.primary,
              fontFamily: "'Poppins', sans-serif",
            }}
          >
            SAYVIA
          </Typography>

          <Stack spacing={2}>
            {menuItems.map((item) => (
              <Button
                key={item}
                fullWidth
                onClick={() => setOpen(false)}
                sx={{
                  justifyContent: "flex-start",
                  color: colors.primary,
                  fontWeight: 600,
                  textTransform: "none",
                  "&:hover": {
                    backgroundColor: `${colors.primary}10`,
                  },
                }}
              >
                {item}
              </Button>
            ))}

            <Button
              fullWidth
              onClick={() => setOpen(false)}
              sx={{
                mt: 2,
                borderRadius: 14,
                backgroundColor: colors.primary,
                color: colors.white,
                fontWeight: 700,
                textTransform: "none",
                boxShadow: "0 10px 25px rgba(249,115,22,0.35)",
                "&:hover": {
                  backgroundColor: "#EA580C",
                },
              }}
            >
              Pesan Sekarang!
            </Button>
          </Stack>
        </Box>
      </Drawer>
    </>
  );
};

export default Navbar;
